// نظام الحسابات والاشتراكات — Firebase Authentication + Firestore
// يستخدم نفس إعدادات Firebase الموجودة في firebase-init.js
import { initializeApp, getApps, getApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, sendPasswordResetEmail, onAuthStateChanged, updateProfile
} from "https://www.gstatic.com/firebasejs/10.8.1/firebase-auth.js";
import {
  getFirestore, doc, getDoc, setDoc, collection, query, where, getDocs,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyD3RlyAtObwMMyeZz4ghYdhxHd3H2JTonY",
  authDomain: "hacker-5ca96.firebaseapp.com",
  projectId: "hacker-5ca96",
  storageBucket: "hacker-5ca96.firebasestorage.app",
  messagingSenderId: "453811300864",
  appId: "1:453811300864:web:0a5e2e41c220434d5806e5",
  measurementId: "G-SDVYMK9130"
};
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export async function registerStudent({name,email,password}) {
  const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
  if (name?.trim()) await updateProfile(cred.user, {displayName:name.trim()});
  await setDoc(doc(db,"users",cred.user.uid), {
    uid:cred.user.uid, name:name.trim(), email:email.trim().toLowerCase(),
    role:"student", status:"active", createdAt:serverTimestamp()
  });
  return cred.user;
}
export async function loginStudent(email,password) {
  const result = await signInWithEmailAndPassword(auth,email.trim(),password);
  const snap = await getDoc(doc(db,"users",result.user.uid));
  if (!snap.exists() || snap.data().status === "disabled") {
    await signOut(auth);
    throw new Error("الحساب غير مفعّل. تواصل مع إدارة المنصة.");
  }
  return result.user;
}
export async function resetStudentPassword(email) {
  return sendPasswordResetEmail(auth,email.trim());
}
export async function logoutStudent() { return signOut(auth); }
export async function getStudentProfile(uid) {
  const snap = await getDoc(doc(db,"users",uid));
  return snap.exists() ? snap.data() : null;
}
export async function getMySubscriptions(uid) {
  const q = query(collection(db,"subscriptions"),where("studentUid","==",uid));
  const snaps = await getDocs(q);
  const now = Date.now();
  return snaps.docs.map(s=>({id:s.id,...s.data()})).filter(s =>
    s.status === "active" && (!s.endsAt || new Date(s.endsAt).getTime() > now)
  );
}
export function hasCourseAccess(subscriptions, courseId, isFree=false) {
  if (isFree) return true;
  return subscriptions.some(s => s.courseId === courseId &&
    s.status === "active" && (!s.endsAt || new Date(s.endsAt).getTime() > Date.now()));
}
export function watchStudent(callback) { return onAuthStateChanged(auth, callback); }
